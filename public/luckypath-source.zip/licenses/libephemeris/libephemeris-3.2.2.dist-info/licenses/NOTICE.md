# NOTICE

LibEphemeris is an astronomical ephemeris library for Python with a Swiss
Ephemeris-compatible API, licensed under the **GNU Affero General Public
License v3.0** (see [LICENSE](LICENSE) and [LICENSING.md](LICENSING.md)).

## Data and Model Sources

All astronomical computations are based on:

- **JPL DE440/DE441** planetary and lunar ephemerides, accessed through the
  local [Skyfield](https://rhodesmill.org/skyfield/) path (Brandon Rhodes, MIT
  license), precomputed LEB coefficients, or NASA JPL Horizons state vectors
  ([bundled base-core build attestation](docs/leb/base-core-provenance.md))
- **IAU 2006/2000A** precession-nutation and **Vondrak 2011** long-term
  precession, via [pyerfa](https://github.com/liberfa/pyerfa) (BSD-3-Clause)
- **Peer-reviewed academic sources**, including:
  - Meeus, J. -- *Astronomical Algorithms*, 2nd ed. (1998)
  - Simon, J.L. et al. -- A&A 282, 663 (1994)
  - Chapront, J. et al. -- A&A 387, 700 (2002), for independent lunar context
  - Park, R.S. et al. -- "The JPL Planetary and Lunar Ephemerides DE440 and
    DE441", AJ 161, 105 (2021)
  - Lieske, J.H. -- "Galilean satellite ephemerides E5", A&AS 129, 205 (1998)
- **Historical hypothetical-body conventions (IDs 40-58)**. Per-body source
  status is documented in the
  [per-body source record](docs/methodology/hypothetical-bodies.md); the six
  IDs without a source-complete model fail closed, as inventoried in the
  [missing-models inventory](docs/methodology/missing-hypothetical-models.md).
- **Sidereal zero points and catalogue geometry** documented per mode in the
  [ayanamsha source table](docs/reference/ayanamsha.md).

The path-exact inventory of every runtime module, generator, development tool,
and shipped scientific asset is the
[algorithm/data provenance registry](docs/methodology/provenance-registry.toml),
with a human-readable derivation map in
[Algorithm and Data Provenance](docs/methodology/algorithm-provenance.md).

## API Compatibility

LibEphemeris provides an API signature-compatible with the reference
ephemeris API (function names, parameters and flag constants match, e.g.
`calc_ut`, `houses`, `julday`) to allow drop-in migration. API compatibility
does not imply code derivation.

## Validation

Compatibility with the reference API is verified by calling its public
interface and comparing outputs. These comparisons are ephemeral: no
reference output is persisted, fitted, or committed. Reference-distribution
source, prose, algorithms, and data files are not part of the shipped
package, and automated provenance gates (`scripts/check_provenance.py`,
`scripts/check_algorithm_provenance.py`) enforce both boundaries through
the test suite and release checks.

The registry and focused methodology pages state exactly which numerical data
and models are reproducible from a primary/public source, which are generated
from public data, and which historical API values remain labelled Secondary or
Convention. Mean lunar points use ERFA's IERS 2003 Delaunay arguments; true and
osculating points use the active NASA JPL state; and supported historical
hypothetical models use the cited primary publications in their source record.
No secondary attribution or project convention is represented as a primary
scientific measurement.

## Vendored Components

Three files are vendored or adapted third-party code and keep their upstream
licenses, all permissive (MIT): `vendor/spktype21.py`,
`moon_theories/tass17.py`, and `moon_theories/tass17_data.py`. The full
inventory: [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

## AI-Assisted Development

Parts of this codebase were developed with AI assistance, including Anthropic
Claude and OpenAI Codex, under the direction and review of the project author.
Copyright in the project-authored work is held by Giacomo Battaglia.

## Trademarks

"Swiss Ephemeris" is a product name of Astrodienst AG. References to it in
this repository are nominative only (interface compatibility). LibEphemeris is
not affiliated with, or endorsed by, Astrodienst AG.
